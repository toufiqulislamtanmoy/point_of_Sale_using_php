<?php
$views="sels_pending";
include('tamplate.php');
?>