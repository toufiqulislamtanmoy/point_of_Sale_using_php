<?php


$views="manage_vendors";
include('tamplate.php');
?>