<?php
$views="home";
include('tamplate.php');


?>