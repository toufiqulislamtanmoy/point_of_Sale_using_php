<?php
$views="sell_product_records";
include("tamplate.php");
?>