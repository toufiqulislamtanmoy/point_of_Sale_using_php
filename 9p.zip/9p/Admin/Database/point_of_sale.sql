-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 13, 2022 at 06:52 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `point_of_sale`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_company`
--

CREATE TABLE `add_company` (
  `companyID` int(11) NOT NULL,
  `CompanyName` varchar(120) NOT NULL,
  `CompanyStatus` tinyint(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `add_company`
--

INSERT INTO `add_company` (`companyID`, `CompanyName`, `CompanyStatus`) VALUES
(1, 'LG', 1),
(2, 'VIVO', 1),
(3, 'SONY', 1),
(4, 'Samphony', 1),
(5, 'Relmi', 1),
(6, 'HP', 1),
(7, 'Phonix', 1),
(8, 'Frees', 0);

-- --------------------------------------------------------

--
-- Table structure for table `buyers`
--

CREATE TABLE `buyers` (
  `buyId` int(255) NOT NULL,
  `vendorName` varchar(60) NOT NULL,
  `vCompany` varchar(60) NOT NULL,
  `productCode` varchar(60) NOT NULL,
  `productName` varchar(70) NOT NULL,
  `productDiscription` varchar(120) NOT NULL,
  `productPrice` int(11) NOT NULL,
  `productQuantity` int(11) NOT NULL,
  `totalAmount` int(11) NOT NULL,
  `payAmount` int(11) NOT NULL,
  `pendingAmount` int(255) NOT NULL,
  `buyDate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `buyers`
--

INSERT INTO `buyers` (`buyId`, `vendorName`, `vCompany`, `productCode`, `productName`, `productDiscription`, `productPrice`, `productQuantity`, `totalAmount`, `payAmount`, `pendingAmount`, `buyDate`) VALUES
(7, 'Mr. Tanmoy Islam', 'HP', 'a-20', 'Asus', 'Good', 17000, 3, 51000, 51000, 0, '2022-07-23 10:56:57'),
(8, 'Olied Islam', 'Phonix', 'p-20', 'Chaina Phonix', 'Good', 7000, 10, 70000, 70000, 0, '2022-07-23 10:59:50'),
(9, 'Mr. Jhon', 'SONY', 'sony-j4', 'Sony P49', 'This product is very confortable and relaiable', 9000, 3, 27000, 27000, 0, '2022-07-23 11:03:45'),
(10, 'Mr.Charlo', 'Relmi', 'm-5', 'Relmi note 8 pro', 'This product is very confortable and relaiable', 14000, 3, 42000, 42000, 0, '2022-07-23 11:10:50'),
(11, 'Md Rohan', 'Samphony', 'sam-69', 'Samphony Z-30', 'Good', 7000, 8, 56000, 56000, 0, '2022-07-23 11:12:09'),
(12, 'Mr. Tanmoy Islam', 'LG', 'p-20', 'Mobile', 'This product is very confortable and relaiable', 7000, 10, 70000, 70000, 0, '2022-07-23 22:29:40'),
(13, 'Mr. Tanmoy Islam', 'LG', 'p-20', 'Cycle', 'Nothing', 7000, 1, 7000, 7000, 0, '2022-07-25 10:04:45'),
(14, 'Md Sayam', 'Phonix', 'p-20', 'Cycle', 'This product is very confortable and relaiable', 8000, 1, 8000, 8000, 0, '2022-07-29 21:25:52'),
(15, 'Mr. Tanmoy Islam', 'LG', 'l12', 'LG Butterfly', 'This product is very confortable and relaiable', 12000, 1, 12000, 12000, 0, '2022-07-29 21:28:55'),
(16, 'Olied Islam', 'Samphony', 'm-5', 'Samsung Galaxy a73 5g', 'This product is very confortable and relaiable', 7000, 1, 7000, 7000, 0, '2022-07-29 22:30:23'),
(17, 'Md Rohan', 'Samphony', 'p-20', 'Mobile', 'Good', 17000, 1, 17000, 17000, 0, '2022-07-29 23:06:52'),
(18, 'Mr.Charlo', 'SONY', 'c-87', 'Camera', 'This product is very confortable and relaiable', 29000, 1, 29000, 29000, 0, '2022-07-29 23:16:50'),
(19, 'Md Sayam', 'Samphony', 'c-87', 'Samphony Z-30', 'Nothing', 9000, 1, 9000, 9000, 0, '2022-08-07 09:40:38'),
(20, 'Mr.Charlo', 'LG', 'a-20', 'Samsung Galaxy a73 5g', 'Nothing', 17000, 4, 68000, 68000, 0, '2022-08-08 09:51:11'),
(21, 'Md Sayam', 'Samphony', 'c-87', 'Samphony Z-30', 'Good', 9000, 1, 9000, 9000, 0, '2022-08-08 09:54:02'),
(22, 'Olied Islam', 'VIVO', 'V-19', 'VIVO y-15', 'This product is very confortable and relaiable', 13000, 2, 26000, 26000, 0, '2022-08-10 21:23:05');

-- --------------------------------------------------------

--
-- Table structure for table `selers`
--

CREATE TABLE `selers` (
  `salersID` int(255) NOT NULL,
  `customerName` varchar(80) NOT NULL,
  `customerAddress` varchar(80) NOT NULL,
  `customerPhoneNumber` varchar(15) NOT NULL,
  `productCode` varchar(50) NOT NULL,
  `productName` varchar(80) NOT NULL,
  `productPrice` int(255) NOT NULL,
  `productQuantity` int(255) NOT NULL,
  `productDiscount` int(255) NOT NULL,
  `totalAmount` int(255) NOT NULL,
  `discountAmount` int(255) NOT NULL,
  `payAmount` int(255) NOT NULL,
  `pendingAmount` int(255) NOT NULL,
  `sells_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `selers`
--

INSERT INTO `selers` (`salersID`, `customerName`, `customerAddress`, `customerPhoneNumber`, `productCode`, `productName`, `productPrice`, `productQuantity`, `productDiscount`, `totalAmount`, `discountAmount`, `payAmount`, `pendingAmount`, `sells_date`) VALUES
(2, 'Tanmoy Islam', 'Rajshahi, Bangladesh', '0184818479', 'a-20', 'Chaina Phonix', 9000, 1, 10, 9000, 8100, 8100, 0, '2022-08-10 20:45:03'),
(3, 'Erfan Khan', 'Rajshahi, Bangladesh', '01744890772', 'a-20', 'Samsung Galaxy a73 5g', 17000, 1, 11, 17000, 15130, 15130, 0, '2022-08-10 20:45:03'),
(4, 'Olied Islam', 'Rajshahi, Bangladesh', '01848189482', 'p-20', 'LG Butterfly', 32000, 1, 15, 32000, 27200, 27200, 0, '2022-08-10 20:46:03'),
(5, 'Imran Khan', 'Rajshahi, Bangladesh', '018481894821479', 'm-5', 'Xmi z5', 17000, 1, 0, 17000, 17000, 17000, 0, '2022-08-10 21:34:26'),
(6, 'Tushar Imarn', 'Rajshahi, Bangladesh', '01756931215', 'z-30', 'Samphony X serise', 11000, 1, 0, 11000, 11000, 11000, 0, '2022-08-10 21:36:41'),
(7, 'Toufiqul Islam Tanmoy', 'Rajshahi, Bangladesh', '01848189482', 'B-140', 'LG Butterfly', 7000, 1, 10, 7000, 6300, 6300, 0, '2022-08-10 21:38:48');

-- --------------------------------------------------------

--
-- Table structure for table `vendors`
--

CREATE TABLE `vendors` (
  `vendorId` int(255) NOT NULL,
  `vendorName` varchar(50) NOT NULL,
  `vCompany` varchar(50) NOT NULL,
  `vendorStatus` tinyint(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vendors`
--

INSERT INTO `vendors` (`vendorId`, `vendorName`, `vCompany`, `vendorStatus`) VALUES
(1, 'Mr. Tanmoy Islam', 'LG', 1),
(2, 'Olied Islam ', 'VIVO', 1),
(3, 'Md Rohan', 'Samphony', 1),
(4, 'Mr. Jhon', 'SONY', 1),
(5, 'Mr.Charlo', 'Relmi', 1),
(6, 'Md Sayam', 'HP', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_company`
--
ALTER TABLE `add_company`
  ADD PRIMARY KEY (`companyID`);

--
-- Indexes for table `buyers`
--
ALTER TABLE `buyers`
  ADD PRIMARY KEY (`buyId`);

--
-- Indexes for table `selers`
--
ALTER TABLE `selers`
  ADD PRIMARY KEY (`salersID`);

--
-- Indexes for table `vendors`
--
ALTER TABLE `vendors`
  ADD PRIMARY KEY (`vendorId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_company`
--
ALTER TABLE `add_company`
  MODIFY `companyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `buyers`
--
ALTER TABLE `buyers`
  MODIFY `buyId` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `selers`
--
ALTER TABLE `selers`
  MODIFY `salersID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `vendors`
--
ALTER TABLE `vendors`
  MODIFY `vendorId` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
