<?php
$views="sell_product_next";
include('tamplate.php');
?>