<?php

$views="pending";
include('tamplate.php');

?>