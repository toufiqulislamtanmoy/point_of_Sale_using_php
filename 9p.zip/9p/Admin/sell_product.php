<?php

$views="sell_product";
include('tamplate.php');

?>