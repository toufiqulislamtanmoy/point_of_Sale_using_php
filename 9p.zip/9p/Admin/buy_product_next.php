<?php
$views="buy_product_next";
include("tamplate.php");
?>