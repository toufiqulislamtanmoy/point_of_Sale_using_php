<?php
$views="buy_product";
include("tamplate.php");
?>