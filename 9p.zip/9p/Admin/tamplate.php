<?php include('functions/main.php'); ?>
<?php include('includes/header.php'); ?>

<body>

    <body>

        <!-- Pre-loader start -->
        <div class="theme-loader">
            <div class="loader-track">
                <div class="loader-bar"></div>
            </div>
        </div>
        <!-- Pre-loader end -->
        <div id="pcoded" class="pcoded">
            <div class="pcoded-overlay-box"></div>
            <div class="pcoded-container navbar-wrapper">
                <?php include_once('includes/top_nav.php'); ?>

                <div class="pcoded-main-container">
                    <div class="pcoded-wrapper">
                        <?php include_once('includes/left_nav.php'); ?>
                        <div class="pcoded-content">
                            <div class="pcoded-inner-content">
                                <div class="main-body">
                                    <div class="page-wrapper">

                                        <div class="page-body">
                                            <?php
                                            if ($views == "dashboard") {
                                                include('views/dashboard-view.php');
                                            }else if($views=="add_company"){
                                                include('views/add_company-view.php');
                                            }
                                            else if($views=="manage_company"){
                                                include('views/manage_company_view.php');
                                            }else if($views=="add_vendors"){
                                                include('views/add_vendors_view.php');
                                            }else if($views=="manage_vendors"){
                                                include('views/manage_vendors_view.php');
                                            }else if($views=="update_company"){
                                                include('views/update_view_company.php');
                                            }else if($views=="update_vendor"){
                                                include('views/update_vendor_view.php');
                                            }
                                            else if($views=="buy_product"){
                                                include('views/buy_product_view.php');
                                            }else if($views=="buy_product_next"){
                                                include('views/buy_product_next-view.php');
                                            }else if($views=="buy_product_records"){
                                                include('views/buy_product_records-view.php');
                                            }else if($views=="pending"){
                                                include('views/pending-view.php');
                                            }else if($views=="sell_product"){
                                                include('views/sell_product-view.php');
                                            }else if($views=="sell_product_next"){
                                                include('views/sell_product_next-view.php');
                                            }else if($views=="sell_product_records"){
                                                include('views/sell_product_records-view.php');
                                            }else if($views=="sels_pending"){
                                                include('views/sels_pending-view.php');
                                            }else if($views=="home"){
                                                include('views/sels_pending-view.php');
                                            }


                                            ?>

                                        </div>

                                        <div id="styleSelector">

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php include('includes/scripts.php'); ?>