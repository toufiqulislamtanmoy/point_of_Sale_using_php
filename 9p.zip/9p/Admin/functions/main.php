<?php

class Main
{
    private $conn;
    function __construct()
    {
        $db_host = "localhost";
        $db_user = "root";
        $db_pass = "";
        $db_name = "point_of_sale";
        $this->conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
        if (!$this->conn) {
            die("Database Connection Error");
        } else {
        }
    }


    function add_company($data)
    {
        $CompanyName = $data['CompanyName'];
        $CompanyStatus = $data['CompanyStatus'];
        $query = "INSERT INTO add_company(CompanyName,CompanyStatus) VALUES ('$CompanyName',$CompanyStatus)";
        $add_company_query = mysqli_query($this->conn, $query);
        if ($add_company_query) {
            //return $msg = "Add Successfuly";
?>
            <script>
                alert("Data Add Successfuly");
                window.location.replace("manage_company.php");
            </script>
        <?php
        } else {
            //return $msg = "Can Not Add";
        ?>
            <script>
                alert("Company could Not Added");
            </script>
        <?php
        }
    }

    function displayCompany()
    {
        $query = "SELECT *From add_company";
        $Disp_com_query = mysqli_query($this->conn, $query);
        if ($Disp_com_query) {
            return $Disp_com_query;
        } else {
            $error_disp = "Did not perfrom that task";
        }
    }
    /*Manage Company Module*/

    function display_prev_company_value($id)
    {
        $query = "SELECT *FROM add_company WHERE companyID =$id";
        $company_prev_info = mysqli_query($this->conn, $query);
        if ($company_prev_info) {
            $company_info_fetch = mysqli_fetch_assoc($company_prev_info);
            return $company_info_fetch;
        }
    }

    function update_company_details($data)
    {
        $companyID = $data['update_companyID'];
        $up_company_name = $data['update_company_name'];
        $query = "UPDATE add_company SET CompanyName='$up_company_name' WHERE companyID= $companyID";
        $update_company_query = mysqli_query($this->conn, $query);
        if ($update_company_query) {
            //$update_msg="Company Update Successfully";
            //return $update_msg;
        ?>
            <script>
                alert("Company Update Successfully");
                window.location.replace("manage_company.php");
            </script>
        <?php
        } else {
        ?>
            <script>
                alert("Company Did Not Updated");
            </script>
        <?php
        }
    }

    function makePublish($id)
    {
        $query = "UPDATE add_company SET CompanyStatus=1 WHERE companyID=$id";
        $update_status_query = mysqli_query($this->conn, $query);
        if ($update_status_query) {
        ?>
            <script>
                alert("Activate Successfully");
                window.location.replace("manage_company.php");
            </script>
        <?php
        } else {
        ?>
            <script>
                alert("Can Not Update");
            </script>
        <?php

        }
    }
    function makeUnpublish($id)
    {
        $query = "UPDATE add_company SET CompanyStatus=0 WHERE companyID=$id";
        $update_status_query = mysqli_query($this->conn, $query);
        if ($update_status_query) {
        ?>
            <script>
                alert("Deactivate Successfully");
                window.location.replace("manage_company.php");
            </script>
        <?php
        } else {
        ?>
            <script>
                alert("Can Not Update");
            </script>
        <?php
        }
    }
    function DeleteCompany($id)
    {
        $query = "DELETE FROM add_company WHERE companyID=$id";
        $update_status_query = mysqli_query($this->conn, $query);
        if ($update_status_query) {
        ?>
            <script>
                alert("Record Deleted Successfully");
                window.location.replace("manage_company.php");
            </script>
        <?php
        } else {
        ?>
            <script>
                alert("Can Not Delete");
            </script>
        <?php
        }
    }
    /*Add Vendors Module*/
    function Company_display_dynamicly()
    {
        $query = "select *from add_company where CompanyStatus=1";
        $disp_query = mysqli_query($this->conn, $query);
        if (isset($disp_query)) {
            return $disp_query;
        }
    }
    function addVendors($data)
    {
        $vendor_name = $data['vendorName'];
        $vendor_company = $data['vCompany'];
        $vendor_status = $data['vendorStatus'];
        $query = "INSERT INTO vendors(vendorName,vCompany,vendorStatus) VALUES ('$vendor_name','$vendor_company',$vendor_status)";
        $add_vendor_query = mysqli_query($this->conn, $query);
        if ($add_vendor_query) {
        ?>
            <script>
                alert("Record Added Successfully");
                window.location.replace("manage_vendors.php");
            </script>
        <?php
        } else {
        ?>
            <script>
                alert("Can Not Add Data");
            </script>
        <?php
        }
    }
    /*Manage Vendors Module*/

    function display_prev_vendor_value($id)
    {
        $query = "SELECT *FROM vendors WHERE vendorId=$id";
        $vendor_prev_info = mysqli_query($this->conn, $query);
        if ($vendor_prev_info) {
            $vendor_info_fetch = mysqli_fetch_assoc($vendor_prev_info);
            return $vendor_info_fetch;
        }
    }

    function update_vendors_details($data)
    {
        $VendroID = $data['update_vendorID'];
        $up_Vendor_name = $data['update_vendor_name'];
        $up_Vendor_company = $data['update_vendor_company'];
        $query = "UPDATE vendors SET vendorName='$up_Vendor_name', vCompany='$up_Vendor_company' WHERE vendorId=$VendroID";
        $update_vendor_query = mysqli_query($this->conn, $query);
        if ($update_vendor_query) {
            //$update_msg="Company Update Successfully";
            //return $update_msg;
        ?>
            <script>
                alert("Company Update Successfully");
                window.location.replace("manage_vendors.php");
            </script>
        <?php
        } else {
        ?>
            <script>
                alert("Company Did Not Updated");
            </script>
        <?php
        }
    }


    function manageVendors()
    {
        $query = "SELECT *FROM vendors";
        $dip_vendors_query = mysqli_query($this->conn, $query);
        if ($dip_vendors_query) {
            return $dip_vendors_query;
        } else {
            return $error_disp = "Did not perfrom that task";
        }
    }



    function make_Online_Vendors($id)
    {
        $query = "UPDATE vendors SET vendorStatus=1 WHERE vendorId =$id";
        $update_status_query = mysqli_query($this->conn, $query);
        if ($update_status_query) {
        ?>
            <script>
                alert("Vendor Is in Online Successfuly");
                window.location.replace("manage_vendors.php");
            </script>
        <?php
        } else {
        ?>
            <script>
                alert("Can Not Active");
            </script>
        <?php
        }
    }
    function make_Offline_Vendors($id)
    {
        $query = "UPDATE vendors SET vendorStatus=0 WHERE vendorId =$id";
        $update_status_query = mysqli_query($this->conn, $query);
        if ($update_status_query) {
        ?>
            <script>
                alert("Vendor Is in Offline Successfuly");
                window.location.replace("manage_vendors.php");
            </script>
        <?php
        } else {
        ?>
            <script>
                alert("Can Not Deactive");
            </script>
        <?php
        }
    }
    function delete_Vendors($id)
    {
        $query = "DELETE FROM vendors WHERE vendorId=$id";
        $update_status_query = mysqli_query($this->conn, $query);
        if ($update_status_query) {
        ?>
            <script>
                alert("Delete Vendor Successfull");
            </script>
        <?php
        } else {
        ?>
            <script>
                alert("Can Not Delete");
            </script>
            <?php
        }
    }
    //Buy Product Module Start
    function disply_vendor_list()
    { //Display all the vendors which are active
        $query = "SELECT vendorName From vendors WHERE vendorStatus=1";
        $vendor_list = mysqli_query($this->conn, $query);
        if ($vendor_list) {
            return $vendor_list;
        } else {
            return $error_disp = "Did not perfrom that task";
        }
    }
    function display_company_list()
    { //Display All the company list which is active
        $query = "SELECT CompanyName From add_company WHERE CompanyStatus=1";
        $Company_list = mysqli_query($this->conn, $query);
        if ($Company_list) {
            return $Company_list;
        } else {
            return $error_disp = "Did not perfrom that task";
        }
    }

    function buy_product($data1, $data2)
    { //Insert Buy product records
        $vendorName = $data1['vendorName'];
        $productCompany = $data1['productCompany'];
        $productCode = $data1['productCode'];
        $productName = $data1['productName'];
        $productDiscription = $data1['productDiscription'];
        $productPrice = $data1['productPrice'];
        $productQuantity = $data1['productQuantity'];
        $totalAmount = $data2['totalAmount'];
        $payAmount = $data2['payAmount'];

        $pendingAmount = ($totalAmount - $payAmount);



        if ($pendingAmount >= 0) {
            $query = "INSERT INTO buyers(vendorName,vCompany,productCode,productName,productDiscription,productPrice,productQuantity,totalAmount,payAmount,pendingAmount)
            VALUES('$vendorName','$productCompany','$productCode','$productName','$productDiscription',$productPrice,$productQuantity,$totalAmount,$payAmount,$pendingAmount)";
            $add_buy_data = mysqli_query($this->conn, $query);
            if ($add_buy_data) {
            ?>

                <script>
                    alert("Record Successfully");
                    <?php session_unset(); ?>
                    window.location.replace("dashboard.php");
                </script>

            <?php
            } else {
                echo "Add buy data is empty";
            }
        } else {
            echo "Pay Amount is greter than total amount";
        }
    }

    //End the buy product module
    //Start Display Buy product records
    function buy_product_records()
    {
        $query = "SELECT *FROM buyers";
        $product_records = mysqli_query($this->conn, $query);
        return $product_records;
    }
    function sum_of_buy_product_records()
    {
        $query = "SELECT SUM(productPrice) AS Product_Price,SUM(productQuantity) AS productQuantity,SUM(totalAmount) AS Total_Buy,SUM(payAmount) AS payAmount,SUM(pendingAmount) AS pendingAmount FROM buyers";
        $sum_all_total = mysqli_query($this->conn, $query);
        $total_buy = mysqli_fetch_array($sum_all_total);
        return $total_buy;
    }
    //Buy product records end here
    //Start last 30 day record
    function this_month_record()
    {
        $query = "SELECT SUM(productQuantity) AS CproductQuantity,SUM(totalAmount) AS CTotal_Buy FROM buyers WHERE month(buyDate) = month(CURRENT_DATE) AND year(buyDate)=year(CURRENT_DATE)";
        $current_month_records = mysqli_query($this->conn, $query);
        $CMR = mysqli_fetch_array($current_month_records);
        if ($CMR) {
            return $CMR;
        }
    }
    //End last 30 day record
    //Start Todays record
    function todays_buy_record()
    { //show todays records
        $query = "SELECT *FROM buyers WHERE day(buyDate)=day(CURRENT_DATE) AND month(buyDate)=month(CURRENT_DATE)";
        $today_records = mysqli_query($this->conn, $query);
        return $today_records;
    }
    function today_total_sum()
    {
        $query = "SELECT SUM(productPrice) AS Product_Price,SUM(productQuantity) AS productQuantity,SUM(totalAmount) AS Total_Buy,SUM(payAmount) AS payAmount,SUM(pendingAmount) AS pendingAmount FROM buyers WHERE buyDate > CURRENT_DATE - INTERVAL 1 day";
        $today_sum_all_total = mysqli_query($this->conn, $query);
        $today_total_buy = mysqli_fetch_array($today_sum_all_total);
        return $today_total_buy;
    }

    //Pending amount pay
    function display_pending_amount($id)
    {
        $query = "SELECT *FROM buyers WHERE buyId =$id";
        $pending_info = mysqli_query($this->conn, $query);
        if ($pending_info) {
            $pending_info_fetch = mysqli_fetch_assoc($pending_info);
            return $pending_info_fetch;
        }
    }

    function pending_amount_pay($data)
    {
        $pendindID = $data['buyID'];
        $total_pay_prev = $data['total_pay_prev'];
        $pending_amount = $data['pending_amount'];
        $pay_amount = $data['Pay_amount'];
        $reminning_amount = $pending_amount - $pay_amount;
        $update_pay_amount= $total_pay_prev+$pay_amount;
        if ($reminning_amount < 0) {
            ?>
            <script>
                alert("Pay amount is greter then Pending Amount");
            </script>
            <?php
        } else {
            $query = "UPDATE buyers SET pendingAmount=$reminning_amount, payAmount=$update_pay_amount WHERE buyId=$pendindID";
            $update_pending = mysqli_query($this->conn, $query);
            if ($update_pending) {
            ?>
                <script>
                    alert("Pay Successfull");
                    window.location.replace("dashboard.php");
                </script>
            <?php
            }else{
                ?>
                <script>
                    alert("Did Not update Pending Amount");
                    window.location.replace("buy_product_records.php");
                </script>
                <?php
            }
        }


        //$query = "UPDATE add_company SET CompanyName='$up_company_name' WHERE companyID= $companyID";

    }

    //Sell product module start here
    function sell_product($data1, $data2)
    { //Insert Buy product records
        $customerName = $data1['customerName'];
        $customerAddress = $data1['customerAddress'];
        $customerPhoneNumber = $data1['customerPhoneNumber'];
        $productCode = $data1['productCode'];
        $productName = $data1['productName'];
        $productPrice = $data1['productPrice'];
        $productQuantity = $data1['productQuantity'];
        $productDiscount = $data1['discount'];
        $totalAmount = $data2['totalAmount'];
        $discountAmount = $data2['discountAmount'];
        $payAmount = $data2['payAmount'];

        $pendingAmount = ($discountAmount - $payAmount);



        if ($pendingAmount >= 0) {
            $query = "INSERT INTO selers(customerName,customerAddress,customerPhoneNumber,productCode,productName,productPrice,productQuantity,productDiscount,totalAmount,discountAmount,payAmount,pendingAmount)
            VALUES('$customerName','$customerAddress','$customerPhoneNumber','$productCode','$productName',$productPrice,$productQuantity,$productDiscount,$totalAmount,$discountAmount ,$payAmount,$pendingAmount)";
            $add_sell_data = mysqli_query($this->conn, $query);
            if ($add_sell_data) {
            ?>

                <script>
                    alert("Record Successfully");
                    <?php session_unset(); ?>
                    window.location.replace("sell_product_records.php");
                </script>

            <?php
            } else {
                echo "Add Sell data is empty";
            }
        } else {
            echo "Pay Amount is greter than total amount";
        }
    }

    //Start Display sell product records
    function sell_product_records()
    {
        $query = "SELECT *FROM selers";
        $selles_product_records = mysqli_query($this->conn, $query);
        return $selles_product_records;
    }
    function sum_of_sel_product_records()
    {
        $query = "SELECT SUM(productPrice) AS Product_Price,SUM(productQuantity) AS productQuantity,SUM(productDiscount) AS discount_percentage ,SUM(totalAmount) AS Total_sell,SUM(discountAmount) AS discount_amount,SUM(payAmount) AS payAmount,SUM(pendingAmount) AS pendingAmount FROM selers";
        $sum_all_total = mysqli_query($this->conn, $query);
        $total_sell = mysqli_fetch_array($sum_all_total);
        return $total_sell;
    }
    //Sell product records display end here


     //Sells Pending amount pay
     function display_sels_pending_amount($id)
     {
         $query = "SELECT *FROM selers WHERE salersID =$id";
         $pending_info = mysqli_query($this->conn, $query);
         if ($pending_info) {
             $pending_info_fetch = mysqli_fetch_assoc($pending_info);
             return $pending_info_fetch;
         }
     }
 
     function sell_pending_amount_pay($data)
     {
         $pendindID = $data['salersID'];
         $total_pay_prev = $data['total_pay_prev'];
         $pending_amount = $data['pending_amount'];
         $pay_amount = $data['Pay_amount'];
         $reminning_amount = $pending_amount - $pay_amount;
         $update_pay_amount= $total_pay_prev+$pay_amount;
         if ($reminning_amount < 0) {
             ?>
             <script>
                 alert("Pay amount is greter then Pending Amount");
             </script>
             <?php
         } else {
             $query = "UPDATE selers SET pendingAmount=$reminning_amount, payAmount=$update_pay_amount WHERE salersID=$pendindID";
             $update_pending = mysqli_query($this->conn, $query);
             if ($update_pending) {
             ?>
                 <script>
                     alert("Pay Successfull");
                     window.location.replace("dashboard.php");
                 </script>
             <?php
             }else{
                 ?>
                 <script>
                     alert("Did Not update Pending Amount");
                     window.location.replace("sell_product_records.php");
                 </script>
                 <?php
             }
         }
     }

     function todays_sells_record(){
        $query = "SELECT *FROM selers WHERE day(sells_date)=day(CURRENT_DATE) AND month(sells_date)=month(CURRENT_DATE)";
        $today_sells_records = mysqli_query($this->conn, $query);
        return $today_sells_records;
     }

     function today_total_sells_sum()
    {
        $query = "SELECT SUM(productPrice) AS Product_Price,SUM(productQuantity) AS productQuantity,SUM(productDiscount) AS discount_percentage ,SUM(totalAmount) AS Total_sell,SUM(discountAmount) AS discount_amount,SUM(payAmount) AS payAmount,SUM(pendingAmount) AS pendingAmount FROM selers WHERE sells_date > CURRENT_DATE - INTERVAL 1 day";
        $today_sum_all_total_sell = mysqli_query($this->conn, $query);
        $today_total_sell = mysqli_fetch_array($today_sum_all_total_sell);
        return $today_total_sell;
    }
    //monthly sells sum
    function monthly_sells_sum()
    {
        $query = "SELECT SUM(productPrice) AS Product_Price,SUM(productQuantity) AS productQuantity,SUM(productDiscount) AS discount_percentage ,SUM(totalAmount) AS Total_sell,SUM(discountAmount) AS discount_amount,SUM(payAmount) AS payAmount,SUM(pendingAmount) AS pendingAmount FROM selers WHERE month(sells_date) = month(CURRENT_DATE) AND year(sells_date)=year(CURRENT_DATE)";
        $current_month_sells_records = mysqli_query($this->conn, $query);
        $CMSR = mysqli_fetch_array($current_month_sells_records);
        if ($CMSR) {
            return $CMSR;
        }
    }
}
