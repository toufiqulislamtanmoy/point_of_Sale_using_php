<?php
$objmain = new Main();
if (isset($_SESSION)) {

    $session_value = $_SESSION;
    $productQuantity = $session_value['productQuantity'];
    $discount_percent = $session_value['discount'];
    $dis_amount=($discount_percent/100);
    
    $productPrice = $session_value['productPrice'];
    $totalAmount=$productPrice*$productQuantity;
    $discount_amount=$totalAmount*$dis_amount;
    $total_discount_amount=$totalAmount-$discount_amount;
    
} else {

}

if(isset($_POST['sell'])){
    if(isset($session_value)){
        echo "Both Are True";
        $return_value=$objmain->sell_product($session_value,$_POST);
        //echo $return_value;

    }else{
        echo "Session value are not set";
    }
}else{
    echo "Pay Is not set";
}

?>

<hr>
<h3 class="text-center text-secondary text-style">Sell Product</h3>
<hr>

<form action="" method="POST" class="text-style text-size">

    <div class="form-group">
        <label for="totalAmount">Total Amount</label>
        <input type="text" name="totalAmount" required value="<?php echo $totalAmount; ?>" class="form-control" placeholder="Enter Product Code">
    </div>

    <div class="form-group">
        <label for="discountAmount">Discount Amount</label>
        <input type="text" name="discountAmount" value="<?php echo $total_discount_amount; ?>" class="form-control" placeholder="Enter Product Code">
    </div>

    
    <div class="form-group">
        <label for="payAmount">Pay Amount</label>
        <input type="text" name="payAmount" required class="form-control" placeholder="Enter Product Code">
    </div>


    <input type="submit" name="sell" value="sell" class="btn btn-success btn-block"> <br>



</form>