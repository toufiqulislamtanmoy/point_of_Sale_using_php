<?php

$objmain = new Main();
$return_data = $objmain->manageVendors();
if (isset($_GET['status'])) {
    $get_id = $_GET['id'];
    if ($_GET['status'] == "deactivate") {
        $return_msg = $objmain->make_Online_Vendors($get_id);
    } else if ($_GET['status'] == "activate") {
        $return_msg = $objmain->make_Offline_Vendors($get_id);
    } else if ($_GET['status'] == "delete") {
        $return_msg = $objmain->delete_Vendors($get_id);
    }
}

?>
<hr>
<h3 class="text-center text-secondary text-style">Manage Vendors</h3>
<hr>
<div class="container tbl-container">
    <div class="row tbl-fixed">
        <table class="table text-style text-size">
            <thead>
                <tr>
                    <th>Vendor Id</th>
                    <th>Vendor Name</th>
                    <th>Company</th>
                    <th>Vendor Status</th>
                    <th>Update or Delete</th>
                </tr>
            </thead>

            <tbody>

                <?php
                while ($update = mysqli_fetch_assoc($return_data)) {
                ?>
                    <tr class="">
                        <td><?php echo $update['vendorId']; ?></td>
                        <td><?php echo $update['vendorName'];  ?></td>
                        <td><?php echo $update['vCompany'];  ?></td>
                        <td>
                            <?php
                            if ($update['vendorStatus'] == 0) {
                                echo "Deactive";
                            ?>
                                <a class="btn btn-success btn-sm" href="?status=deactivate&&id=<?php echo $update['vendorId']; ?>">Make Active</a>

                            <?php
                            } else {
                                echo "Active";
                            ?>
                                <a class="btn btn-danger btn-sm" href="?status=activate&&id=<?php echo $update['vendorId']; ?>">Make Deactive</a>
                            <?php
                            }
                            ?>
                        </td>
                        <td>
                            <a class="btn btn-success btn-sm" href="update_vendor.php?status=update&&id=<?php echo $update['vendorId']; ?>">Update</a>
                            <a class="btn btn-danger btn-sm" href="?status=delete&&id=<?php echo $update['vendorId']; ?>">Delete</a>
                        </td>
                    </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>
</div>