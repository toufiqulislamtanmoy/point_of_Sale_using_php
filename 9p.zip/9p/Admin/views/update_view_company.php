<?php

$objmain = new Main();

if (isset($_GET['status'])) {
    $get_id = $_GET['id'];
    if ($_GET['status'] == 'update') {
        $return_data = $objmain->display_prev_company_value($get_id);
    }
}
if (isset($_POST['update_btn'])) {
    $update_return_msg = $objmain->update_company_details($_POST);
}


?>


<h1 class="text-center text-secondary">Update Company Details</h1>



<form action="" method="post">


    <h4 class="mt-5 text-success">
        <?php
        if (isset($update_return_msg)) {
            echo $update_return_msg;
        }
        ?>
    </h4>


    <div class="form-group">

        <input hidden type="text" name="update_companyID" value="<?php echo $return_data['companyID']; ?>" class="form-control">
    </div>

    <div class="form-group">
        <label for="update_catagory_name">Updated Company Name</label>
        <input type="text" name="update_company_name" value="<?php echo $return_data['CompanyName']; ?>" class="form-control">
    </div>


    <input type="submit" name="update_btn" value="Update" class="btn btn-success">
</form>