<?php

$objmain = new Main();

$return_data = $objmain->Company_display_dynamicly();

if (isset($_POST['add_vendor'])) {
    $return_msg = $objmain->addVendors($_POST);
}


?>
<hr>
<h3 class="text-center text-secondary text-style">Add Vendors</h3>
<hr>
<form action="" method="POST" class="text-style text-size mt-5">
    <div class="form-group">
        <label for="vendorName">Vendor Name</label>
        <input type="text" name="vendorName" class="form-control" placeholder="Enter Vendor Name">
    </div>

    <div class="form-group">
        <label for="vCompany">Company</label>
        <select name="vCompany" class="form-control">
            <option>Select a Company</option>
            <?php

            while ($data = mysqli_fetch_assoc($return_data)) {
            ?>
                <option><?php echo $data['CompanyName'];  ?></option>
            <?php
            }
            ?>
        </select>
    </div>

    <div class="form-group">
        <label for="vendorStatus">Vendor Status</label>
        <select name="vendorStatus" class="form-control">
            <option value="0">Offline</option>
            <option value="1">Online</option>
        </select>
    </div>
    <input type="submit" name="add_vendor" value="Add Vendors" class="btn btn-success btn-block">
    <?php

    if (isset($return_msg)) {
        if ($return_msg == "Add Vendor Successfully") { ?>
            <h4 class="mt-5 text-success">
                <?php echo $return_msg; ?>
            </h4>
        <?php
        } else { ?>
            <h4 class="mt-5 text-danger">
                <?php
                echo $return_msg;
                ?>
            </h4>
    <?php
        }
    }

    ?>
</form>