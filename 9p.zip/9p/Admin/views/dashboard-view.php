<?php

$objmain = new Main();
$sum_off_all_total = $objmain->sum_of_buy_product_records();
$this_month_record = $objmain->this_month_record();
$this_month_sels_record=$objmain->monthly_sells_sum();
$todays_buy_records = $objmain->todays_buy_record();
$todays_sells_records = $objmain->todays_sells_record();
$today_total_sells= $objmain->today_total_sells_sum();
$today_total = $objmain->today_total_sum();
$sum_off_all_sells_total=$objmain->sum_of_sel_product_records();

$profit=$sum_off_all_sells_total['discount_amount']- $sum_off_all_total['Total_Buy'];
$this_month_profit=$this_month_sels_record['discount_amount']-$this_month_record['CTotal_Buy'];


?>
<div class="row">

    <!-- order-card start -->

    <div class="col-md-6 col-xl-3">
        <div class="card bg-secondary order-card">
            <div class="card-block">
                <h6 class="m-b-20">Total Quantity Buy</h6>
                <h2 class="text-right"><i class="ti-shopping-cart f-left"></i><span><?php echo $sum_off_all_total['productQuantity']; ?></span></h2>
                <p class="m-b-0">This Month<span class="f-right"><?php echo $this_month_record['CproductQuantity']; ?></span></p>
            </div>
        </div>
    </div>


    <div class="col-md-6 col-xl-3">
        <div class="card bg-c-blue order-card">
            <div class="card-block">
                <h6 class="m-b-20">Total Buy</h6>
                <h2 class="text-right"><i class="ti-shopping-cart f-left"></i><span>&#2547;<?php echo $sum_off_all_total['Total_Buy']; ?></span></h2>
                <p class="m-b-0">This Month<span class="f-right">&#2547;<?php echo $this_month_record['CTotal_Buy']; ?></span></p>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-xl-3">
        <div class="card bg-c-green order-card">
            <div class="card-block">
                <h6 class="m-b-20">Total Sales</h6>
                <h2 class="text-right"><i class="ti-tag f-left"></i><span>&#2547;<?php echo $sum_off_all_sells_total['discount_amount']; ?></span></h2>
                <p class="m-b-0">This Month<span class="f-right">&#2547;<?php echo $this_month_sels_record['discount_amount']; ?></span></p>
            </div>
        </div>
    </div>
    
    <div class="col-md-6 col-xl-3">
        <div class="card bg-c-pink order-card">
            <div class="card-block">
                <h6 class="m-b-20">Total Profit</h6>
                <h2 class="text-right"><i class="ti-wallet f-left"></i><span>&#2547;<?php echo $profit; ?></span></h2>
                <p class="m-b-0">This Month<span class="f-right">&#2547;<?php echo $this_month_profit; ?></span></p>
            </div>
        </div>
    </div>
    <!-- order-card end -->




    <!-- Daily purchase Record -->
    <div class="container tbl-container">
        <h3 class="text-center text-secondary text-style">Todays purchase Records</h3>
        <div class="row tbl-fixed">
            <table class="table table-striped.table-condensed">
                <thead>
                    <tr>
                        <th>Serial No</th>
                        <th>Vendor Name</th>
                        <th>Product Catagory</th>
                        <th>Product Code</th>
                        <th>Product Name</th>
                        <th>Product Discription</th>
                        <th>Product Price</th>
                        <th>Quentity</th>
                        <th>Total Amount</th>
                        <th>Pay Amount</th>
                        <th>Pending Amount</th>
                        <th>Buy Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $counter = 1;
                    while ($TBR = mysqli_fetch_assoc($todays_buy_records)) {

                    ?>
                        <tr class="text-style">
                            <td><?php echo $counter; ?></td>
                            <td><?php echo $TBR['vendorName']; ?></td>
                            <td><?php echo $TBR['vCompany']; ?></td>
                            <td><?php echo $TBR['productCode']; ?></td>
                            <td><?php echo $TBR['productName']; ?></td>
                            <td><?php echo $TBR['productDiscription']; ?></td>
                            <td><?php echo $TBR['productPrice']; ?></td>
                            <td><?php echo $TBR['productQuantity']; ?></td>
                            <td><?php echo $TBR['totalAmount']; ?></td>
                            <td><?php echo $TBR['payAmount']; ?></td>
                            <td>
                            <?php 
                                if($TBR['pendingAmount']==0){
                                echo "Paid" ;
                            }else{
                                echo $TBR['pendingAmount'];
                                ?> <a class="btn btn-danger btn-sm" href="pending.php?status=pay&&id=<?php echo $TBR['buyId'];?>">Pay</a>
                            <?php
                            }
                            ?>
                        </td>
                            <td><?php echo $TBR['buyDate']; ?></td>
                        </tr>

                    <?php
                        $counter++;
                    }
                    ?>

                    <tr class="bg-secondary">
                        <td colspan="6" class="font-weight-bold">Total</td>
                        <td class="font-weight-bold"><?php echo $today_total['Product_Price']; ?></td>
                        <td class="font-weight-bold"><?php echo $today_total['productQuantity']; ?></td>
                        <td class="font-weight-bold"><?php echo $today_total['Total_Buy']; ?></td>
                        <td class="font-weight-bold"><?php echo $today_total['payAmount']; ?></td>
                        <td class="font-weight-bold">
                        <?php 
                            if($today_total['pendingAmount'] > 0) {
                                echo $today_total['pendingAmount']; 
                            }else {
                                echo "N/A";
                            }
                            
                        ?>
                        </td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <!-- Daily Selles Record -->
    <div class="container tbl-container">
        <h3 class="text-center text-secondary text-style">Todays Selles Records</h3>
        <div class="row tbl-fixed">
            <table class="table table-striped.table-condensed">
                <thead>
                    <tr>
                        <th>Serial No</th>
                        <th>Customer Name</th>
                        <th>Customer Address</th>
                        <th>Customer PhoneNumber</th>
                        <th>Product Code</th>
                        <th>Product Name</th>
                        <th>Product Price</th>
                        <th>Quentity</th>
                        <th>Discount Percentage</th>
                        <th>Total Amount</th>
                        <th>Discount Amount</th>
                        <th>Pay Amount</th>
                        <th>Pending Amount</th>
                        <th>Selles Date</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $counter = 1;
                while ($product_records = mysqli_fetch_assoc($todays_sells_records)) {

                ?>
                    <tr class="text-style">
                        <td><?php echo $counter; ?></td>
                        <td><?php echo $product_records['customerName']; ?></td>
                        <td><?php echo $product_records['customerAddress']; ?></td>
                        <td><?php echo $product_records['customerPhoneNumber']; ?></td>
                        <td><?php echo $product_records['productCode']; ?></td>
                        <td><?php echo $product_records['productName']; ?></td>
                        <td><?php echo $product_records['productPrice']; ?></td>
                        <td><?php echo $product_records['productQuantity']; ?></td>
                        <td><?php echo $product_records['productDiscount']; ?>%</td>
                        <td><?php echo $product_records['totalAmount']; ?></td>
                        <td><?php echo $product_records['discountAmount']; ?></td>
                        <td><?php echo $product_records['payAmount']; ?></td>
                        <td>
                            <?php 
                                if($product_records['pendingAmount']==0){
                                echo "Paid" ;
                            }else{
                                echo $product_records['pendingAmount'];
                                ?> <a class="btn btn-danger btn-sm" href="sels_pending.php?status=pay&&id=<?php echo $product_records['salersID'];?>">Pay</a>
                            <?php
                            }
                            ?>
                        </td>
                        <td><?php echo $product_records['sells_date']; ?></td>
                    </tr>

                <?php
                    $counter++;
                }

                ?>
                <tr class="bg-secondary">
                    <td colspan="6" class="font-weight-bold">Total</td>
                    <td class="font-weight-bold">N/A</td>
                    <td class="font-weight-bold">N/A</td>
                    <td class="font-weight-bold">N/A</td>
                    <td class="font-weight-bold"><?php echo $today_total_sells['Total_sell']; ?></td>
                    <td class="font-weight-bold"><?php echo $today_total_sells['discount_amount']; ?></td>
                    <td class="font-weight-bold"><?php echo $today_total_sells['payAmount']; ?></td>
                    <td class="font-weight-bold">
                        <?php 
                            if($today_total_sells['pendingAmount'] > 0) {
                                echo $today_total_sells['pendingAmount']; 
                            }else {
                                echo "N/A";
                            }
                            
                        ?>
                    </td>
                    <td></td>
                </tr>
            </tbody>
            </table>
        </div>
    </div>



</div>