<?php
$objmain = new Main();
if (isset($_SESSION)) {

    $session_value = $_SESSION;
    $productQuantity = $session_value['productQuantity'];
    $productPrice = $session_value['productPrice'];
    $totalAmount=$productPrice*$productQuantity;
    
} else {

}

if(isset($_POST['Buy'])){
    if(isset($session_value)){
        echo "Both Are True";
        $return_value=$objmain->buy_product($session_value,$_POST);
        echo $return_value;

    }else{
        //echo "Session value are not set";
    }
}else{
    //echo "Pay Is not set";
}

?>


<hr>
<h3 class="text-center text-secondary text-style">Buy Product</h3>
<hr>

<form action="" method="POST" class="text-style text-size">

    <div class="form-group">
        <label for="totalAmount">Total Amount</label>
        <input type="text" name="totalAmount" value="<?php echo $totalAmount; ?>" class="form-control" placeholder="Enter Product Code">
    </div>

    
    <div class="form-group">
        <label for="payAmount">Pay Amount</label>
        <input type="text" required name="payAmount" class="form-control" placeholder="Enter Product Code">
    </div>


    <input type="submit" name="Buy" value="Buy" class="btn btn-success btn-block"> <br>



</form>