<?php

$objmain = new Main();

if (isset($_GET['status'])) {
    $get_id = $_GET['id'];
    if ($_GET['status'] == 'pay') {
        $return_data = $objmain->display_pending_amount($get_id);
    }
}
if (isset($_POST['Pay'])) {
    $update_return_msg = $objmain->pending_amount_pay($_POST);

}


?>

<h3>Pending Amount Pay</h3>

<form action="" method="post" class="text-style text-size mt-5">
    <div class="form-group">

        <input hidden type="text" name="buyID" value="<?php echo $return_data['buyId']; ?>" class="form-control">
    </div>
    <div class="form-group">

        <input hidden type="text" name="total_pay_prev" value="<?php echo $return_data['payAmount']; ?>" class="form-control">
    </div>
    <div class="form-group  pb-2">
        <label for="CompanyName">Panding Amount</label>
        <input type="text" class="form-control" name="pending_amount" value="<?php echo $return_data['pendingAmount']; ?>">
    </div>

    <div class="form-group  pb-2">
        <label for="CompanyName">Pay Amount</label>
        <input type="text" class="form-control" name="Pay_amount" placeholder="Pay amount">
    </div>


    <input type="submit" class="btn btn-success" value="Pay" name="Pay"> <br>
</form>