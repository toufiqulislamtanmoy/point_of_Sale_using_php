<?php
$objmain = new Main();
$Company_data = $objmain->displayCompany();

if (isset($_GET['status'])) {
    $get_id = $_GET['id'];
    if ($_GET['status'] == "unpublish") {
        $return_msg = $objmain->makePublish($get_id);
    } else if ($_GET['status'] == "publish") {
        $return_msg = $objmain->makeUnpublish($get_id);
    } else if ($_GET['status'] == "delete") {
        $return_msg = $objmain->DeleteCompany($get_id);
    }
}

?>


<hr>
<h3 class="text-center text-secondary text-style">Manage Company</h3>
<hr>
<div class="container tbl-container">
    <div class="row tbl-fixed">
        <table class="table text-style text-size">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Company Name</th>
                    <th>Company Status</th>
                    <th>Update or Delete</th>
                </tr>
            </thead>

            <tbody>

                <?php
                while ($cgt = mysqli_fetch_assoc($Company_data)) {
                ?>
                    <tr class="">
                        <td><?php echo $cgt['companyID']; ?></td>
                        <td><?php echo $cgt['CompanyName']; ?></td>
                        <td>
                            <?php
                            if ($cgt['CompanyStatus'] == 0) {
                                echo "Deactive";
                            ?>
                                <a class="btn btn-success btn-sm" href="?status=unpublish&&id=<?php echo $cgt['companyID']; ?>">Make Active</a>

                            <?php
                            } else {
                                echo "Active";
                            ?>
                                <a class="btn btn-danger btn-sm" href="?status=publish&&id=<?php echo $cgt['companyID']; ?>">Make Deactive</a>
                            <?php
                            }
                            ?>
                        </td>

                        <td>
                            <a class="btn btn-success btn-sm " href="update_company.php?status=update&&id=<?php echo $cgt['companyID']; ?>">Update</a>
                            <a class="btn btn-danger btn-sm" href="?status=delete&&id=<?php echo $cgt['companyID']; ?>">Delete</a>
                        </td>
                    </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>
</div>