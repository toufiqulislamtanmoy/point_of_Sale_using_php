<?php

$objmain = new Main();
$returnData = $objmain->buy_product_records();
$sum_off_all_total = $objmain->sum_of_buy_product_records();




?>

<hr>
<h3 class="text-center text-secondary text-style">Purchase Records</h3>
<hr>
<div class="container tbl-container">
    <div class="row tbl-fixed">
        <table class="table table-striped.table-condensed">
            <thead>
                <tr >
                    <th>Serial No</th>
                    <th>Vendor Name</th>
                    <th>Product Catagory</th>
                    <th>Product Code</th>
                    <th>Product Name</th>
                    <th>Product Discription</th>
                    <th>Product Price</th>
                    <th>Quentity</th>
                    <th>Total Amount</th>
                    <th>Pay Amount</th>
                    <th>Pending Amount</th>
                    <th>Buy Date</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $counter = 1;
                while ($product_records = mysqli_fetch_assoc($returnData)) {

                ?>
                    <tr class="text-style">
                        <td><?php echo $counter; ?></td>
                        <td><?php echo $product_records['vendorName']; ?></td>
                        <td><?php echo $product_records['vCompany']; ?></td>
                        <td><?php echo $product_records['productCode']; ?></td>
                        <td><?php echo $product_records['productName']; ?></td>
                        <td><?php echo $product_records['productDiscription']; ?></td>
                        <td><?php echo $product_records['productPrice']; ?></td>
                        <td><?php echo $product_records['productQuantity']; ?></td>
                        <td><?php echo $product_records['totalAmount']; ?></td>
                        <td><?php echo $product_records['payAmount']; ?></td>
                        <td>
                            <?php 
                                if($product_records['pendingAmount']==0){
                                echo "Paid" ;
                            }else{
                                echo $product_records['pendingAmount'];
                                ?> <a class="btn btn-danger btn-sm" href="pending.php?status=pay&&id=<?php echo $product_records['buyId'];?>">Pay</a>
                            <?php
                            }
                            ?>
                        </td>
                        <td><?php echo $product_records['buyDate']; ?></td>
                    </tr>

                <?php
                    $counter++;
                }

                ?>
                <tr class="bg-secondary">
                    <td colspan="6" class="font-weight-bold">Total</td>
                    <td class="font-weight-bold"><?php echo $sum_off_all_total['Product_Price']; ?></td>
                    <td class="font-weight-bold"><?php echo $sum_off_all_total['productQuantity']; ?></td>
                    <td class="font-weight-bold"><?php echo $sum_off_all_total['Total_Buy']; ?></td>
                    <td class="font-weight-bold"><?php echo $sum_off_all_total['payAmount']; ?></td>
                    <td class="font-weight-bold">
                        <?php 
                            if($sum_off_all_total['pendingAmount'] > 0) {
                                echo $sum_off_all_total['pendingAmount']; 
                            }else {
                                echo "N/A";
                            }
                            
                        ?>
                    </td>
                    <td></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>