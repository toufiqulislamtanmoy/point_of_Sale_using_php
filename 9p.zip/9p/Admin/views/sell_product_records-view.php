<?php

$objmain = new Main();
$returnData = $objmain->sell_product_records();
$sum_off_all_total = $objmain->sum_of_sel_product_records();




?>

<hr>
<h3 class="text-center text-secondary text-style">Selles Records</h3>
<hr>
<div class="container tbl-container">
    <div class="row tbl-fixed">
        <table class="table table-striped.table-condensed">
            <thead>
                <tr >
                    <th>Serial No</th>
                    <th>Customer Name</th>
                    <th>Customer Address</th>
                    <th>Customer Phone Number</th>
                    <th>Product Code</th>
                    <th>Product Name</th>
                    <th>Product Price</th>
                    <th>Quentity</th>
                    <th>Discount Percentage</th>
                    <th>Total Amount</th>
                    <th>Discount Amount</th>
                    <th>Pay Amount</th>
                    <th>Pending Amount</th>
                    <th>Selles Date</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $counter = 1;
                while ($product_records = mysqli_fetch_assoc($returnData)) {

                ?>
                    <tr class="text-style">
                        <td><?php echo $counter; ?></td>
                        <td><?php echo $product_records['customerName']; ?></td>
                        <td><?php echo $product_records['customerAddress']; ?></td>
                        <td><?php echo $product_records['customerPhoneNumber']; ?></td>
                        <td><?php echo $product_records['productCode']; ?></td>
                        <td><?php echo $product_records['productName']; ?></td>
                        <td><?php echo $product_records['productPrice']; ?></td>
                        <td><?php echo $product_records['productQuantity']; ?></td>
                        <td><?php echo $product_records['productDiscount']; ?>%</td>
                        <td><?php echo $product_records['totalAmount']; ?></td>
                        <td><?php echo $product_records['discountAmount']; ?></td>
                        <td><?php echo $product_records['payAmount']; ?></td>
                        <td>
                            <?php 
                                if($product_records['pendingAmount']==0){
                                echo "Paid" ;
                            }else{
                                echo $product_records['pendingAmount'];
                                ?> <a class="btn btn-danger btn-sm" href="sels_pending.php?status=pay&&id=<?php echo $product_records['salersID'];?>">Pay</a>
                            <?php
                            }
                            ?>
                        </td>
                        <td><?php echo $product_records['sells_date']; ?></td>
                    </tr>

                <?php
                    $counter++;
                }

                ?>
                <tr class="bg-secondary">
                    <td colspan="6" class="font-weight-bold">Total</td>
                    <td class="font-weight-bold">N/A</td>
                    <td class="font-weight-bold">N/A</td>
                    <td class="font-weight-bold">N/A</td>
                    <td class="font-weight-bold"><?php echo $sum_off_all_total['Total_sell']; ?></td>
                    <td class="font-weight-bold"><?php echo $sum_off_all_total['discount_amount']; ?></td>
                    <td class="font-weight-bold"><?php echo $sum_off_all_total['payAmount']; ?></td>
                    <td class="font-weight-bold">
                        <?php 
                            if($sum_off_all_total['pendingAmount'] > 0) {
                                echo $sum_off_all_total['pendingAmount']; 
                            }else {
                                echo "N/A";
                            }
                            
                        ?>
                    </td>
                    <td></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>