<?php
$objmain=new Main();
if(isset($_POST['Add_btn'])){
    $rmsg=$objmain->add_company($_POST);
}


?>

<hr>
<h3 class="text-center text-secondary text-style" >Add Company</h3>
<hr>
<form action="" method="post" class="text-style text-size mt-5">
    <div class="form-group  pb-2">
        <label for="CompanyName">Company Name</label>
        <input type="text" class="form-control" name="CompanyName" placeholder="Enter Company Name">
    </div>

    <div class="form-group pb-2">
        <label for="CompanyStatus" >Status</label>
        <select name="CompanyStatus" id="" class="form-control">
            <option value="1">Active</option>
            <option value="0">Deactive</option>
        </select>
    </div>
    <input type="submit" class="btn btn-success" value="Add Company" name="Add_btn"> <br>
    <?php
    if(isset($rmsg)){
        if($rmsg=="Add Successfuly"){
            ?> <h4 class="text-success"><?php echo $rmsg ?></h4><?php
        }else{
            ?><h4 class="text-denger"><?php echo $rmsg ?></h4>   <?php
        }
    }
    ?>
</form>