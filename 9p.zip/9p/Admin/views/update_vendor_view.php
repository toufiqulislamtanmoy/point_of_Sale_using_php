<?php

$objmain = new Main();

if (isset($_GET['status'])) {
    $get_id = $_GET['id'];
    if ($_GET['status'] == 'update') {
        $return_data = $objmain->display_prev_vendor_value($get_id);
    }
}
if (isset($_POST['update_btn'])) {
    $update_return_msg = $objmain->update_vendors_details($_POST);
  
}


?>



<h1 class="text-center text-secondary header">Update Vendors Details</h1>



<form action="" method="post">


    <h4 class="mt-5 text-success">
        
    </h4>


    <div class="form-group">

        <input hidden type="text" name="update_vendorID" value="<?php echo $return_data['vendorId']; ?>" class="form-control">
    </div>

    <div class="form-group">
        <label for="update_vendor_name">Update Vendor Name</label>
        <input type="text" name="update_vendor_name" value="<?php echo $return_data['vendorName']; ?>" class="form-control">
    </div>

    <div class="form-group">
        <label for="update_vendor_company">Update Vendor Company</label>
        <input type="text" name="update_vendor_company" value="<?php echo $return_data['vCompany']; ?>" class="form-control">
    </div>


    <input type="submit" name="update_btn" value="Update" class="btn btn-success">
</form>