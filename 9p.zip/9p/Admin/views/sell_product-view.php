<?php
$objmain = new Main();
$return_data = $objmain->disply_vendor_list();
$return_value = $objmain->display_company_list();

if (isset($_POST['Next'])) {
    $_SESSION = $_POST;
    ?>
    <script> window.location.replace("sell_product_next.php"); </script>
    <?php
?>
    
<?php

}
?>

<hr>
<h3 class="text-center text-secondary text-style">Sell Product</h3>
<hr>
<form action="" method="POST" class="text-style text-size">


    <div class="form-group">
        <label for="customerName">Customer Name</label>
        <input type="text" required name="customerName" class="form-control" placeholder="Enter Customer Name">
    </div>

    <div class="form-group">
        <label for="customerAddress">Customer Address</label>
        <input type="text" required name="customerAddress" class="form-control" placeholder="Enter Customer Address">
    </div>

    <div class="form-group">
        <label for="customerPhoneNumber">Customer Phone Number</label>
        <input type="text" name="customerPhoneNumber" class="form-control" placeholder="Enter Phone Number">
    </div>

    <div class="form-group">
        <label for="productCode">Product Code</label>
        <input type="text" required name="productCode" class="form-control" placeholder="Enter Product Code">
    </div>

    <div class="form-group">
        <label for="productName">Product Name</label>
        <input type="text" required name="productName" class="form-control" placeholder="Enter Product Name">
    </div>


    <div class="form-group">
        <label for="productPrice">Product Price</label>
        <input type="text" required name="productPrice" class="form-control" placeholder="Per Unit">
    </div>

    <div class="form-group">
        <label for="productQuantity">Product Quantity</label>
        <input type="text" required name="productQuantity" class="form-control" placeholder="Enter Quentity">
    </div>

    <div class="form-group">
        <label for="discount">Discount</label>
        <input type="text" required name="discount" value="" class="form-control" placeholder="Enter the discoutnt percentage %">
    </div>


    <input type="submit" name="Next" value="Next" class="btn btn-success btn-block"> <br>



</form>