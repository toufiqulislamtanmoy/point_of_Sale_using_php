
<?php
$objmain = new Main();
$return_data = $objmain->disply_vendor_list();
$return_value = $objmain->display_company_list();

if (isset($_POST['Next'])) {
    $_SESSION = $_POST;
    ?>
    <script> window.location.replace("buy_product_next.php"); </script>
    <?php
?>
    
<?php

}
?>

<hr>
<h3 class="text-center text-secondary text-style">Buy Product</h3>
<hr>
<form action="" method="POST" class="text-style text-size">


    <div class="form-group">
        <label for="vendorName">Select a Vendor</label>
        <select name="vendorName" required class="form-control">
            <option>Select a Vendor</option>
            <?php

            while ($data = mysqli_fetch_assoc($return_data)) {
            ?>
                <option><?php echo $data['vendorName']; ?></option>
            <?php
            }
            ?>

        </select>
    </div>

    <div class="form-group">
        <label for="productCompany">Select a Company</label>
        <select name="productCompany" required class="form-control">
            <option>Select a Catagory</option>
            <?php

            while ($data = mysqli_fetch_assoc($return_value)) {
            ?>
                <option><?php echo $data['CompanyName']; ?></option>
            <?php
            }
            ?>

        </select>
    </div>


    <div class="form-group">
        <label for="productCode">Product Code</label>
        <input type="text" required name="productCode" class="form-control" placeholder="Enter Product Code">
    </div>

    <div class="form-group">
        <label for="productName">Product Name</label>
        <input type="text" required name="productName" class="form-control" placeholder="Enter Product Name">
    </div>

    <div class="form-group">
        <label for="productDiscription">Product Discription</label>
        <input type="text" required name="productDiscription" class="form-control" placeholder="Enter Product Discription">
    </div>

    <div class="form-group">
        <label for="productPrice">Product Price</label>
        <input type="text" required name="productPrice" class="form-control" placeholder="Per Unit">
    </div>

    <div class="form-group">
        <label for="productQuantity">Product Quantity</label>
        <input type="text" required name="productQuantity" class="form-control" placeholder="Enter Quentity">
    </div>


    <input type="submit" name="Next" value="Next" class="btn btn-success btn-block"> <br>



</form>