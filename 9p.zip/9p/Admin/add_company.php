<?php
$views="add_company";
include('tamplate.php');


?>