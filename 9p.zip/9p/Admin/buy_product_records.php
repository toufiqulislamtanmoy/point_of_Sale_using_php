<?php
$views="buy_product_records";
include("tamplate.php");
?>