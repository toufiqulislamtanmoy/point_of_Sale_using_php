<?php

    $views="update_company";
    include('tamplate.php');

?>