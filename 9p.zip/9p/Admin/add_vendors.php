<?php
$views="add_vendors";
include('tamplate.php');


?>