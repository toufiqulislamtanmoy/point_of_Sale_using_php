<?php

$views="update_vendor";
include('tamplate.php');

?>