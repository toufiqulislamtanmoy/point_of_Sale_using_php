<?php
$views="manage_company";
include('tamplate.php');


?>
