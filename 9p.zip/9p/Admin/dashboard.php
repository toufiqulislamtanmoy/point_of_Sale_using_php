<?php 

$views="dashboard";
include('tamplate.php');

?>